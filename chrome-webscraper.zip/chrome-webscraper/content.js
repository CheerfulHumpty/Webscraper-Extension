console.log("content script is working");
chrome.runtime.onMessage.addListener((data, sender, sendResponse) => {
  const selecttor = data.tag||"*"
const elements = [];
if(selecttor == "img"){
  document.querySelectorAll(selecttor).forEach(element => {
    elements.push({
      tag: element.tagName,
      id: element.id || null,
      src : element.src||null,
      width: element.width||null,
      height: element.height||null,
      alt: element.alt||null,
      class: element.className || null,
      text: element.innerText ? element.innerText.trim().slice(0, 300) : null
    });
  });
}
else{
  document.querySelectorAll(selecttor).forEach(element => {
    elements.push({
      tag: element.tagName,
      id: element.id || null,
      class: element.className || null,
      text: element.innerText? element.innerText.trim().slice(0, 300): null
    });
  });
}
  sendResponse({
    total: elements.length,
    data: elements
  });
  return true;
});
