console.log("The script is working")
var buttonclick = false
var button = document.getElementById("button")
var content = document.getElementById("content")
var preview = false
var conData = ""
var view = document.getElementById("preview")
var downloadbtn = document.getElementById("download")
var selector = document.getElementById("select")
view.addEventListener("click", () => {
  preview = preview ? false : true
  if (preview) {
    content.textContent = conData
    content.style.display = "block"
    view.textContent = "HIDE"
  } else {
    content.style.display = "none"
    view.textContent = "VIEW"
  }
})
button.addEventListener("click", () => {
  buttonclick = true
  var tagnamee = selector.value
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id,{action:"scrape", tag: tagnamee}, (data) => {
      conData = JSON.stringify(data, null, 2)
      content.style.display = "none"
      preview = false
      view.textContent = "VIEW"
    })
  })
})
downloadbtn.addEventListener("click", () => {
  downloadfile(conData)
})
function downloadfile(data) {
  const blob = new Blob([data], { type: "text/plain" })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = "scrapedData.txt"
  a.click()
  URL.revokeObjectURL(url)
}
