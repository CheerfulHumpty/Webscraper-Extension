console.log("Popup script loaded");
var button = document.getElementById("button");
var content = document.getElementById("content");
var view = document.getElementById("preview");
var downloadbtn = document.getElementById("download");
var select = document.getElementById("select");
var preview = false;
var conData = "";
button.addEventListener("click", () => {
    var selectval = select.value
  browser.tabs.query({ active: true, currentWindow: true })
    .then(tabs => {
      return browser.tabs.sendMessage(tabs[0].id, {
        action: "scrape",
        tag: selectval
      });
    })
    .then(data => {
      conData = JSON.stringify(data, null, 2);
      content.style.display = "none";
      preview = false;
      view.textContent = "VIEW";
    });
});
view.addEventListener("click", () => {
  preview = preview ? false : true
  if (preview) {
    content.textContent = conData;
    content.style.display = "block";
    view.textContent = "HIDE";
  } else {
    content.style.display = "none";
    view.textContent = "VIEW";
  }
});
downloadbtn.addEventListener("click", () => {
  const blob = new Blob([conData], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "conData.txt";
  a.click();
  URL.revokeObjectURL(url);
});
