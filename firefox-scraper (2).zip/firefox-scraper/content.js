console.log("Content script loaded");
browser.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action !== "scrape") return;
  const tag = msg.tag||"*";
  const elements = [];
  if(tag == "img"){
    document.querySelectorAll(tag).forEach(el => {
    elements.push({
      tag: el.tagName,
      id: el.id || null,
      src : el.src||null,
      width: el.width||null,
      height: el.height||null,
      alt: el.alt||null,
      class: el.className || null,
      text: el.innerText ? el.innerText.trim().slice(0, 300) : null
    });
  });
  }
  else{
    document.querySelectorAll(tag).forEach(el => {
    elements.push({
      tag: el.tagName,
      id: el.id || null,
      class: el.className || null,
      text: el.innerText ? el.innerText.trim().slice(0, 300) : null
    });
  });
  }
  sendResponse({
    total: elements.length,
    data: elements
  });
  return true;
});
